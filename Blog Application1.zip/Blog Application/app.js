require("dotenv").config();
const path = require("path");
const express = require("express");
const mongoose = require("mongoose");
const Blog = require("./models/blog");
const userRoute = require("./routes/user");
const userBlog = require("./routes/blog");
const cookieParser = require('cookie-parser');
const { checkForAuthenticationCookie } = require("./middleware/authentication");
const app = express();
const port = process.env.PORT||3000;

mongoose.connect(process.env.MONGO_URL)
    .then(() => console.log("MongoDB Connected"));

app.set('view engine', 'ejs');
app.set("views", path.resolve("./views"));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(checkForAuthenticationCookie("token"));

// ✅ Serve all static filesapp.use(express.static(path.resolve("/public")));
// app.use(express.static(path.resolve("./public")));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', async (req, res) => {
    const allBlogs = await Blog.find({});
    res.render("home", {
        user: req.user,
        blogs: allBlogs,
    });
});

app.use('/user', userRoute);
app.use('/blog', userBlog);
app.get("/", (req, res) => {
    res.redirect("/home"); // Redirect to the home page
});
app.listen(port, () => console.log(`Server started on port ${port}`));
