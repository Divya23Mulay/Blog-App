const { validateToken } = require("../services/authentication");

function checkForAuthenticationCookie(cookieName){
    return(req,res,next)=>{
        const tokenCookiValue=req.cookies[cookieName];
        if(!tokenCookiValue){
            return next();
        }
        try{
            const userPayLoad=validateToken(tokenCookiValue);
            req.user=userPayLoad;
        }catch(error){
            console.log("invalid token");
        }
         return next();
    };
}
module.exports={
    checkForAuthenticationCookie,
}